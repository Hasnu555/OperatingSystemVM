import java.util.*;

//Main Execution Class
public class Main {
    public static void main(String args[]) {

        //Initializing ProgramLoader,ProcessControlBlock,FreePageList,ReadyQueues,Memory and instructions
        ProgramLoader programLoader = new ProgramLoader();
        ProcessControlBlock process;
        List<Integer> FreePageList = new ArrayList<Integer>();
        List<ProcessControlBlock> Queue1 = new ArrayList<ProcessControlBlock>();
        List<ProcessControlBlock> Queue2 = new ArrayList<ProcessControlBlock>();
        Memory memory = new Memory();
        Instructions instructions = new Instructions();

        //Add all memory pages to free page list
        for (int i = 0; i < 512; i++) {
            FreePageList.add(i);
        }

        //Loading Process from files into Memory
        process = programLoader.Load("flags", memory, FreePageList);
        if (process == null) {
            System.out.println("Flags Is An Invalid Process");  //Invalid Process Error
        } else { //Assigning Processes To Queues Based On Priority
            if (process.Priority <= 15) {
                Queue1.add(process);
            } else {
                Queue2.add(process);
            }
        }
        //Loading Process from files into Memory
        process = programLoader.Load("large0", memory, FreePageList);
        if (process == null) {
            System.out.println("Large0 Is An Invalid Process");  //Invalid Process Error
        } else { //Assigning Processes To Queues Based On Priority
            if (process.Priority <= 15) {
                Queue1.add(process);
            } else {
                Queue2.add(process);
            }
        }
        //Loading Process from files into Memory
        process = programLoader.Load("noop", memory, FreePageList);
        if (process == null) {
            System.out.println("Noop Is An Invalid Process"); //Invalid Process Error
        } else {  //Assigning Processes To Queues Based On Priority
            if (process.Priority <= 15) {
                Queue1.add(process);
            } else {
                Queue2.add(process);
            }
        }
        //Loading Process from files into Memory
        process = programLoader.Load("p5", memory, FreePageList);
        if (process == null) {
            System.out.println("P5 Is An Invalid Process"); //Invalid Process Error
        } else { //Assigning Processes To Queues Based On Priority
            if (process.Priority <= 15) {
                Queue1.add(process);
            } else {
                Queue2.add(process);
            }
        }
        //Loading Process from files into Memory
        process = programLoader.Load("power", memory, FreePageList);
        if (process == null) {
            System.out.println("Power Is An Invalid Process"); //Invalid Process Error
        } else { //Assigning Processes To Queues Based On Priority
            if (process.Priority <= 15) {
                Queue1.add(process);
            } else {
                Queue2.add(process);
            }
        }
        //Loading Process from files into Memory
        process = programLoader.Load("sfull", memory, FreePageList);
        if (process == null) {
            System.out.println("sfull Is An Invalid Process"); //Invalid Process Error
        } else { //Assigning Processes To Queues Based On Priority
            if (process.Priority <= 15) {
                Queue1.add(process);
            } else {
                Queue2.add(process);
            }
        }


        Collections.sort(Queue1,ProcessControlBlock.PPriority);
        System.out.println(Queue1);
        RoundRobin rr = new RoundRobin(Queue2); //class for Scheduling Criteria for Queue 2
        Queue1.remove(2);
        Queue1.remove(0);
        while (!Queue2.isEmpty() || !Queue1.isEmpty()) { //checking whether both Queues are empty or not

            boolean RRorPR; //flag to check process from which queue is running

            int process_time = 0; //as soon as this value goes above 8 in Round Robin Scheduling the scheduling stops

            if (Queue1.isEmpty()) { // if Queue1 is empty, the processes from Queue2 are loaded one by one
                process = Queue2.get(0);
                RRorPR = true;

            } else {
                process = Queue1.get(0); //Loading A Process from Ready Queue
                RRorPR = false;
            }

            //Extracting Opcode from memory and converting it to hexadecimal
            String Opcode = memory.Loadhex(process.SPR.SPR[9].value);

            //Setting Values For Program Counter And Code Limit
            short PC = process.SPR.SPR[9].value;
            short CL = process.SPR.SPR[1].value;

            boolean proc_stop = false; //used to stop the while loop when any process exceeds the limit (>=8)

            //Executing Program until end instruction or Program Counter becomes greater than Code Limit
            while ((PC <= CL) & (!(Opcode.equals("f3"))) & (!proc_stop)) {
                PC = instructions.DecodeExecute(Opcode, memory, process.GPR, process.SPR, PC, process.stack,process); //Executing the instruction
                if (PC == -1) break;
                if(PC!=0)PC++;
                process.SPR.SPR[9].value = PC; //Setting the value of the PC register
                process.SPR.SPR[2].value = PC; //Setting the value of the Code Counter Register
                System.out.println(process.GPR); //Printing the General Purpose Registers
                System.out.println(process.SPR); //Printing the Special Purpose Registers

                if (RRorPR) { //if the process is from queue2 which is RoundRobin
                    process_time += 2; //each iteration in while loops adds 2 unit time
                    Queue2 = rr.incrementExecutionTime(); //incrementing execution time for the process currently running
                    Queue2 = rr.incrementWaitingTime();    //incrementing waiting time for the processes currently waiting in queue

                    if (process_time > 8) { //if the process time exceeds it limit assigned to it
                        Queue2 = rr.reArrange(); //rearrange the queue
                        proc_stop =true; //stop the loop as next process will be loaded, however the opcode will be loaded so its execution time will be added next time this process gets it turn
                        break;
                    }

                }

                if(!proc_stop) {
                    Opcode = memory.Loadhex(PC); //Loading new instruction from memory and converting it to hexadecimal
                }
                if (Opcode == null) break;      //Breaking Execution if no opcode available

            }

            //Displaying Error if Program Counter Becomes Greater Than Code Limit
            if (PC > CL) {
                System.out.println("Accessing out of bound instructions");
            }
            //Printing and Writing To File Memory Dump and PCB of a process on successful execution
            else if (Opcode.equals("f3")) {
                System.out.println("Program executed successfully");
                System.out.println("Data Dump");
//                memory.dump((short) process.SPR.SPR[3].value, (short) process.SPR.SPR[4].value, "Data Dump");
                System.out.println("Stack Dump");
//                process.stack.dump();
                System.out.println("Code Dump");
//                memory.dump((short) process.SPR.SPR[0].value, (short) process.SPR.SPR[1].value, "Code Dump");
                process.dump();

                if (RRorPR) {
                    if (process_time <= 8) { //if any process which is finished before its quantum is finished the Queue will again be rearranged and the particular process will be removed then
                        Queue2 = rr.reArrange();
                        Queue2 = rr.removelast();
                    }
                }
                else {
                    Queue1.remove(process); // Removing a successfully executed process from ready Queue
                }

            }


        }

    }

}
