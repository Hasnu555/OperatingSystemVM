import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Stack {
    Ubyte[] stack = new Ubyte[50]; //size of stack for each process
    int index = 0;

    public Stack(){
        for(int i=0;i<50;i++){
            stack[i]=new Ubyte((byte)0);
        }
    }

    public void push(short S){

        String hex = Integer.toHexString(S & 0xffff);
        if(hex.length()==3){ //Specifying the length of register value
            hex="0"+ hex;
        }
        else if(hex.length()==2){//Specifying the length of register value
            hex="00"+ hex;
        }
        else if(hex.length()==1){//Specifying the length of register value
            hex="000"+ hex;
        }
        System.out.println(hex);

        String part1 = hex.substring(0,2);
        System.out.println(part1);
        String part2 = hex.substring(2,4);
        System.out.println(part2);

        if(index < 50) {
            stack[index].value = Integer.parseInt(part1,16);
            index++;
            stack[index].value = Integer.parseInt(part2,16);
            index++;

        }
        else if(index >= 50){
            System.out.println("Stack Overflow");
        }
    }

    public Ubyte pop(){
        index--;
        int index2 = index;
        if(index<0){
            System.out.println("Stack Underflow");
        }
        else {

            return stack[index2];
        }
        Ubyte b = new Ubyte((byte)(12));
        return b;
    }

    //Printing and Writing Stack To File
    public void dump(){
        try(FileWriter fw = new FileWriter("dump.txt", true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter out = new PrintWriter(bw))
        {
            out.println("Stack Dump");
            for(short i=0;i<50;i++){
                System.out.println(stack[i]);
                out.println(stack[i]);
            }
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        Stack stack = new Stack();
        stack.push((short)300);

        System.out.println(stack.pop().value);
        System.out.println(stack.pop().value);


    }
}