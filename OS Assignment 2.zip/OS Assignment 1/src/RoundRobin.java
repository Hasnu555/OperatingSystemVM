import java.util.Collections;
import java.util.List;

public class RoundRobin {
    int index = 0;
    List<ProcessControlBlock> Queue;
    public RoundRobin(List<ProcessControlBlock> Queue){
        this.Queue = Queue;
    }

    public ProcessControlBlock getProcess(){
        return Queue.get(index);
    }

    public List<ProcessControlBlock> incrementWaitingTime(){
        for(int i=0;i<=Queue.size()-1;i++){
            if(index!=i) {
                Queue.get(i).WaitingTime += 2;
            }
        }
        return Queue;
    }

    public List<ProcessControlBlock> incrementExecutionTime(){
        Queue.get(index).ExecutionTime +=2;
        return Queue;
    }

    public List<ProcessControlBlock> reArrange(){

        Collections.rotate(Queue,-1);

        return Queue;
    }



    public List<ProcessControlBlock> remove(){
        Queue.remove(index);
        return Queue;
    }

    public List<ProcessControlBlock> removelast(){

        Queue.get(Queue.size()-1).ExecutionTime +=2;

        Queue.remove(Queue.size()-1);
        return Queue;
    }





}
